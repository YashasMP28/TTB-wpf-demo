
TrainTicketBooking - Simple WPF App (Demo)
-----------------------------------------
What it is:
- A beginner-friendly WPF app to simulate train ticket booking.
- No database — uses an in-memory list (ObservableCollection) to store bookings while app runs.

How to open:
1. Download and unzip the folder.
2. Open 'TrainTicketBooking.sln' in Visual Studio 2022 (or later).
3. Build and Run (F5). Target framework in project is .NET Framework 4.8 (net48). 
   If you don't have .NET Framework 4.8 targeting pack, you can retarget the project to an installed framework version via project properties.

Key files:
- TrainTicketBooking.sln       : Solution file
- TrainTicketBooking/          : Project folder
    - TrainTicketBooking.csproj
    - App.xaml, App.xaml.cs
    - MainWindow.xaml, MainWindow.xaml.cs
    - Ticket.cs
Notes:
- The UI uses simple XAML controls: TextBox, ComboBox, DatePicker, ListBox, Buttons.
- Bookings are shown in the right panel; click a booking to view details.
- Use 'Show Confirmation' to see a simple confirmation MessageBox.
- This is intentionally simple to teach WPF core concepts (XAML, code-behind, events, data-binding (basic)).
