using System;
using System.Windows;
using System.Windows.Media;

namespace TrainTicketBooking.Theme
{
    public enum ThemeMode
    {
        Light,
        Dark,
        System
    }

    public static class ThemeManager
    {
        private static ThemeMode _currentTheme = ThemeMode.Light;

        public static ThemeMode CurrentTheme
        {
            get => _currentTheme;
            set
            {
                _currentTheme = value;
                ApplyTheme(value);
            }
        }

        private static ThemeMode DetectSystemTheme()
        {
            try
            {
                var appTheme = Microsoft.Win32.Registry.GetValue(
                    @"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize",
                    "AppsUseLightTheme", 1);

                if (appTheme != null && (int)appTheme == 0)
                {
                    return ThemeMode.Dark;
                }
                else
                {
                    return ThemeMode.Light;
                }
            }
            catch
            {
                return ThemeMode.Light;
            }
        }

        public static void ApplyTheme(ThemeMode mode)
        {
            var app = Application.Current;
            if (app == null || app.Resources == null) return;

            var resources = app.Resources;

            if (mode == ThemeMode.System)
            {
                mode = DetectSystemTheme();
                _currentTheme = mode;
            }

            // Update color brushes based on theme
            // Replace brushes instead of modifying them (to avoid frozen brush issues)
            if (mode == ThemeMode.Dark)
            {
                ReplaceBrush(resources, "BackgroundBrush", "#121212");
                ReplaceBrush(resources, "SurfaceBrush", "#1E1E1E");
                ReplaceBrush(resources, "CardBackgroundBrush", "#2D2D2D");
                ReplaceBrush(resources, "PrimaryBrush", "#4A90E2");
                ReplaceBrush(resources, "PrimaryDarkBrush", "#357ABD");
                ReplaceBrush(resources, "SecondaryBrush", "#64B5F6");
                ReplaceBrush(resources, "TextPrimaryBrush", "#FFFFFF");
                ReplaceBrush(resources, "TextSecondaryBrush", "#B0B0B0");
                ReplaceBrush(resources, "BorderBrush", "#424242");
                ReplaceBrush(resources, "ErrorBrush", "#EF5350");
                ReplaceBrush(resources, "SuccessBrush", "#66BB6A");
                ReplaceBrush(resources, "AccentBrush", "#42A5F5");
            }
            else // Light
            {
                ReplaceBrush(resources, "BackgroundBrush", "#FFFFFF");
                ReplaceBrush(resources, "SurfaceBrush", "#F5F5F5");
                ReplaceBrush(resources, "CardBackgroundBrush", "#FFFFFF");
                ReplaceBrush(resources, "PrimaryBrush", "#0B486B");
                ReplaceBrush(resources, "PrimaryDarkBrush", "#083A56");
                ReplaceBrush(resources, "SecondaryBrush", "#1E90FF");
                ReplaceBrush(resources, "TextPrimaryBrush", "#212121");
                ReplaceBrush(resources, "TextSecondaryBrush", "#757575");
                ReplaceBrush(resources, "BorderBrush", "#E0E0E0");
                ReplaceBrush(resources, "ErrorBrush", "#D32F2F");
                ReplaceBrush(resources, "SuccessBrush", "#388E3C");
                ReplaceBrush(resources, "AccentBrush", "#1976D2");
            }
        }

        private static void ReplaceBrush(ResourceDictionary resources, string key, string colorHex)
        {
            try
            {
                if (resources.Contains(key))
                {
                    // Remove the old brush and add a new one (to avoid frozen brush issues)
                    resources.Remove(key);
                }
                // Always create a new brush (never frozen)
                resources[key] = new SolidColorBrush((Color)ColorConverter.ConvertFromString(colorHex));
            }
            catch
            {
                // Silently fail if resource is not available yet
            }
        }
    }
}

