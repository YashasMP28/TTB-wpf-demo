﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace TrainTicketBooking.Converters
{
    public class DateToColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is DateTime date)
            {
                if (date.Date == DateTime.Today)
                    return new SolidColorBrush(Colors.LightGreen);

                if (date.Date < DateTime.Today)
                    return new SolidColorBrush(Colors.LightGray);

                return new SolidColorBrush(Colors.LightBlue);
            }

            return new SolidColorBrush(Colors.Transparent);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
