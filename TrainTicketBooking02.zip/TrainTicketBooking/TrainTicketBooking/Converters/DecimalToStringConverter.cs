using System;
using System.Globalization;
using System.Windows.Data;

namespace TrainTicketBooking.Converters
{
    /// <summary>
    /// Converts decimal values to editable strings and back, tolerating empty input.
    /// </summary>
    public class DecimalToStringConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is decimal decimalValue)
            {
                var format = parameter as string;
                return string.IsNullOrWhiteSpace(format)
                    ? decimalValue.ToString("F2", culture)
                    : decimalValue.ToString(format, culture);
            }

            return "0.00";
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var text = value?.ToString();
            if (string.IsNullOrWhiteSpace(text))
            {
                return 0m;
            }

            if (decimal.TryParse(text, NumberStyles.Any, culture, out var decimalValue))
            {
                return decimalValue;
            }

            return Binding.DoNothing;
        }
    }
}

