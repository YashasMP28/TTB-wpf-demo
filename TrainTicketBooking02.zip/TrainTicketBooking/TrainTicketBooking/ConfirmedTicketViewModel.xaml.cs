﻿using System;
using System.Windows.Input;
using TrainTicketBooking.MVVM;

namespace TrainTicketBooking.MVVM
{
    public class ConfirmedTicketViewModel
{
    public string TrainName { get; }
    public string PassengerName { get; }
    public string ClassType { get; }
    public string PNR { get; }
    public string SeatNumber { get; }
    public string Source { get; }
    public string Destination { get; }

    public ICommand CloseCommand { get; }
    private static readonly Random _rnd = new Random();

    public ConfirmedTicketViewModel(Ticket ticket, Action closeWindow)
    {
        TrainName = ticket?.TrainName ?? "Unknown";
        PassengerName = ticket?.PassengerName ?? "Unknown";
        ClassType = ticket?.ClassType ?? "General";

        Source = ticket?.Source ?? "Unknown";
        Destination = ticket?.Destination ?? "Unknown";

        PNR = GeneratePNR();
        SeatNumber = GenerateSeatNumber();

        CloseCommand = new RelayCommand(_ => closeWindow?.Invoke());
    }

    private string GeneratePNR()
    {
        const string letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        char a = letters[_rnd.Next(letters.Length)];
        char b = letters[_rnd.Next(letters.Length)];
        int num = _rnd.Next(100000, 999999);
        return $"{a}{b}{num}";
    }

    private string GenerateSeatNumber()
    {
        int seat = _rnd.Next(1, 201);
        return $"S{seat}";
    }
    }
}
