namespace TrainTicketBooking.Models
{
    public enum PnrStatus
    {
        Confirmed,
        RAC, // Reservation Against Cancellation
        Waiting,
        Cancelled
    }
}

