using System;
using System.Collections.Generic;

namespace TrainTicketBooking.Models
{
    public class TrainSchedule
    {
        public string TrainNumber { get; set; }
        public string TrainName { get; set; }
        public string Source { get; set; }
        public string Destination { get; set; }
        public IReadOnlyList<string> ViaStations { get; set; }
        public TimeSpan DepartureTime { get; set; }
        public TimeSpan ArrivalTime { get; set; }
        public int DistanceInKm { get; set; }
        public Dictionary<string, int> SeatsByClass { get; set; } = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

        public TrainSchedule Clone()
        {
            return new TrainSchedule
            {
                TrainNumber = TrainNumber,
                TrainName = TrainName,
                Source = Source,
                Destination = Destination,
                ViaStations = new List<string>(ViaStations ?? Array.Empty<string>()),
                DepartureTime = DepartureTime,
                ArrivalTime = ArrivalTime,
                DistanceInKm = DistanceInKm,
                SeatsByClass = new Dictionary<string, int>(SeatsByClass, StringComparer.OrdinalIgnoreCase)
            };
        }
    }
}

