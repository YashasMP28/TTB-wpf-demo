using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace TrainTicketBooking.Behaviors
{
    public static class WindowBehaviors
    {
        // Auto Focus
        public static readonly DependencyProperty AutoFocusProperty =
            DependencyProperty.RegisterAttached("AutoFocus", typeof(bool), typeof(WindowBehaviors),
                new PropertyMetadata(false, OnAutoFocusChanged));

        public static bool GetAutoFocus(DependencyObject obj) => (bool)obj.GetValue(AutoFocusProperty);
        public static void SetAutoFocus(DependencyObject obj, bool value) => obj.SetValue(AutoFocusProperty, value);

        private static void OnAutoFocusChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (d is Control control && (bool)e.NewValue)
            {
                control.Loaded += (s, args) => control.Focus();
            }
        }

        // Drag Move
        public static readonly DependencyProperty DragMoveProperty =
            DependencyProperty.RegisterAttached("DragMove", typeof(bool), typeof(WindowBehaviors),
                new PropertyMetadata(false, OnDragMoveChanged));

        public static bool GetDragMove(DependencyObject obj) => (bool)obj.GetValue(DragMoveProperty);
        public static void SetDragMove(DependencyObject obj, bool value) => obj.SetValue(DragMoveProperty, value);

        private static void OnDragMoveChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (d is FrameworkElement element && (bool)e.NewValue)
            {
                element.MouseLeftButtonDown += (s, args) =>
                {
                    var window = Window.GetWindow(element);
                    window?.DragMove();
                };
            }
        }

        // Shake on Validation Error
        public static readonly DependencyProperty ShakeOnErrorProperty =
            DependencyProperty.RegisterAttached("ShakeOnError", typeof(bool), typeof(WindowBehaviors),
                new PropertyMetadata(false, OnShakeOnErrorChanged));

        public static bool GetShakeOnError(DependencyObject obj) => (bool)obj.GetValue(ShakeOnErrorProperty);
        public static void SetShakeOnError(DependencyObject obj, bool value) => obj.SetValue(ShakeOnErrorProperty, value);

        private static void OnShakeOnErrorChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (d is Control control && (bool)e.NewValue)
            {
                control.Loaded += (s, args) =>
                {
                    if (control.RenderTransform == null || !(control.RenderTransform is TranslateTransform))
                    {
                        control.RenderTransform = new TranslateTransform();
                    }
                };

                Validation.AddErrorHandler(control, (sender, args) =>
                {
                    if (args.Action == ValidationErrorEventAction.Added)
                    {
                        TriggerShake(control);
                    }
                });
            }
        }

        public static void TriggerShake(Control control)
        {
            var transform = control.RenderTransform as TranslateTransform;
            if (transform == null)
            {
                transform = new TranslateTransform();
                control.RenderTransform = transform;
            }

            var storyboard = new Storyboard();
            var animation = new DoubleAnimation
            {
                From = 0,
                To = 10,
                Duration = new Duration(System.TimeSpan.FromMilliseconds(50)),
                AutoReverse = true,
                RepeatBehavior = new RepeatBehavior(3)
            };

            Storyboard.SetTarget(animation, transform);
            Storyboard.SetTargetProperty(animation, new PropertyPath(TranslateTransform.XProperty));
            storyboard.Children.Add(animation);
            storyboard.Begin();
        }
    }
}

