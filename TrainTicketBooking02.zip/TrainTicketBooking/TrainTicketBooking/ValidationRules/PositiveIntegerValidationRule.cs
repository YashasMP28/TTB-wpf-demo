using System;
using System.Globalization;
using System.Windows.Controls;

namespace TrainTicketBooking.ValidationRules
{
    /// <summary>
    /// Ensures the bound value is a positive integer (> 0).
    /// </summary>
    public class PositiveIntegerValidationRule : ValidationRule
    {
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            if (value == null)
            {
                return new ValidationResult(false, "Value is required.");
            }

            if (int.TryParse(Convert.ToString(value, cultureInfo), out var number))
            {
                if (number > 0)
                {
                    return ValidationResult.ValidResult;
                }
                return new ValidationResult(false, "Value must be greater than zero.");
            }

            return new ValidationResult(false, "Invalid number format.");
        }
    }
}

