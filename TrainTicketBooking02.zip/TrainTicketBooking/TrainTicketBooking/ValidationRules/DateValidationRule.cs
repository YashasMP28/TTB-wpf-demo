using System;
using System.Globalization;
using System.Windows.Controls;

namespace TrainTicketBooking.ValidationRules
{
    public class DateValidationRule : ValidationRule
    {
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            if (value is DateTime date)
            {
                if (date.Date < DateTime.Now.Date)
                {
                    return new ValidationResult(false, "Cannot book a ticket for a past date.");
                }
                return ValidationResult.ValidResult;
            }

            return new ValidationResult(false, "Invalid date format.");
        }
    }
}

