using System;
using System.Globalization;
using System.Windows.Controls;

namespace TrainTicketBooking.ValidationRules
{
    public class SourceDestinationValidationRule : ValidationRule
    {
        public string Source { get; set; }
        public string Destination { get; set; }

        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            if (value is string str)
            {
                // This rule will be used with a MultiBinding to check both source and destination
                if (!string.IsNullOrWhiteSpace(Source) && 
                    !string.IsNullOrWhiteSpace(Destination) &&
                    Source.Equals(Destination, StringComparison.OrdinalIgnoreCase))
                {
                    return new ValidationResult(false, "Source and destination cannot be the same.");
                }
            }

            return ValidationResult.ValidResult;
        }
    }
}

