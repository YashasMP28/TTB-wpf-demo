using System;
using System.Collections.Generic;
using System.Linq;

namespace TrainTicketBooking.Services
{
    public class User
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
        public string FullName { get; set; }
        public bool IsAdmin { get; set; }
    }

    public static class AuthenticationService
    {
        private static List<User> _users = new List<User>
        {
            new User { Username = "admin", Password = "admin123", Email = "admin@railway.com", FullName = "System Admin", IsAdmin = true },
            new User { Username = "user", Password = "user123", Email = "user@example.com", FullName = "Test User", IsAdmin = false }
        };

        private static User _currentUser;

        public static User CurrentUser => _currentUser;

        public static bool IsLoggedIn => _currentUser != null;

        public static bool Login(string username, string password)
        {
            var user = _users.FirstOrDefault(u => u.Username == username && u.Password == password);
            if (user != null)
            {
                _currentUser = user;
                return true;
            }
            return false;
        }

        public static void Logout()
        {
            _currentUser = null;
        }

        public static bool Register(string username, string password, string email, string fullName)
        {
            if (_users.Any(u => u.Username == username))
                return false; // Username already exists

            _users.Add(new User
            {
                Username = username,
                Password = password,
                Email = email,
                FullName = fullName,
                IsAdmin = false
            });
            return true;
        }

        public static bool IsAdmin()
        {
            return _currentUser?.IsAdmin ?? false;
        }
    }
}

