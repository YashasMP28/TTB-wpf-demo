using System;
using System.Collections.Generic;
using System.Linq;
using TrainTicketBooking.Models;
using TrainTicketBooking.Services.Contracts;

namespace TrainTicketBooking.Services
{
    public class TrainScheduleService : ITrainScheduleService
    {
        private readonly List<TrainSchedule> _schedules;
        private readonly Dictionary<string, Dictionary<string, int>> _seatInventory;

        public TrainScheduleService()
        {
            _schedules = SeedSchedules().ToList();
            _seatInventory = _schedules.ToDictionary(
                s => s.TrainNumber,
                s => new Dictionary<string, int>(s.SeatsByClass, StringComparer.OrdinalIgnoreCase),
                StringComparer.OrdinalIgnoreCase);
        }

        public IEnumerable<TrainSchedule> GetSchedules() => _schedules.Select(s => s.Clone());

        public bool HasSeats(string trainNumber, string classType, int seatsRequested)
        {
            return GetAvailableSeats(trainNumber, classType) >= seatsRequested;
        }

        public int GetAvailableSeats(string trainNumber, string classType)
        {
            if (trainNumber == null || classType == null)
                return 0;

            if (_seatInventory.TryGetValue(trainNumber, out var seatMap) &&
                seatMap.TryGetValue(classType, out var seats))
            {
                return seats;
            }

            return 0;
        }

        public bool TryReserveSeats(string trainNumber, string classType, int seatsRequested)
        {
            if (!HasSeats(trainNumber, classType, seatsRequested))
                return false;

            _seatInventory[trainNumber][classType] -= seatsRequested;
            return true;
        }

        public void ReleaseSeats(string trainNumber, string classType, int seatsReleased)
        {
            if (trainNumber == null || classType == null || seatsReleased <= 0)
                return;

            if (_seatInventory.TryGetValue(trainNumber, out var seatMap))
            {
                seatMap[classType] = seatMap.TryGetValue(classType, out var seats)
                    ? seats + seatsReleased
                    : seatsReleased;
            }
        }

        private static IEnumerable<TrainSchedule> SeedSchedules()
        {
            yield return new TrainSchedule
            {
                TrainNumber = "12007",
                TrainName = "Shatabdi Express",
                Source = "Bengaluru",
                Destination = "Chennai",
                DepartureTime = new TimeSpan(6, 0, 0),
                ArrivalTime = new TimeSpan(11, 15, 0),
                DistanceInKm = 350,
                ViaStations = new[] { "Katpadi", "Jolarpettai" },
                SeatsByClass = new Dictionary<string, int>
                {
                    { "AC 2 Tier", 60 },
                    { "AC 3 Tier", 120 },
                    { "Sleeper", 200 },
                    { "General", 300 }
                }
            };

            yield return new TrainSchedule
            {
                TrainNumber = "22691",
                TrainName = "Rajdhani Express",
                Source = "Bengaluru",
                Destination = "Delhi",
                DepartureTime = new TimeSpan(20, 0, 0),
                ArrivalTime = new TimeSpan(5, 30, 0),
                DistanceInKm = 2368,
                ViaStations = new[] { "Secunderabad", "Nagpur", "Jhansi" },
                SeatsByClass = new Dictionary<string, int>
                {
                    { "AC 2 Tier", 90 },
                    { "AC 3 Tier", 180 },
                    { "Sleeper", 240 },
                    { "General", 400 }
                }
            };

            yield return new TrainSchedule
            {
                TrainNumber = "16558",
                TrainName = "Mysuru Express",
                Source = "Mysuru",
                Destination = "Bengaluru",
                DepartureTime = new TimeSpan(5, 45, 0),
                ArrivalTime = new TimeSpan(8, 25, 0),
                DistanceInKm = 140,
                ViaStations = new[] { "Mandya", "Kengeri" },
                SeatsByClass = new Dictionary<string, int>
                {
                    { "AC 2 Tier", 30 },
                    { "AC 3 Tier", 60 },
                    { "Sleeper", 120 },
                    { "General", 250 }
                }
            };

            yield return new TrainSchedule
            {
                TrainNumber = "12786",
                TrainName = "Vande Bharat Express",
                Source = "Hyderabad",
                Destination = "Bengaluru",
                DepartureTime = new TimeSpan(15, 15, 0),
                ArrivalTime = new TimeSpan(21, 45, 0),
                DistanceInKm = 570,
                ViaStations = new[] { "Kurnool", "Anantapur" },
                SeatsByClass = new Dictionary<string, int>
                {
                    { "AC 2 Tier", 80 },
                    { "AC 3 Tier", 120 },
                    { "Sleeper", 0 },
                    { "General", 200 }
                }
            };
        }
    }
}

