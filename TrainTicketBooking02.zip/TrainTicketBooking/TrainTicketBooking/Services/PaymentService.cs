using System;
using TrainTicketBooking.Models;
using TrainTicketBooking.Services.Contracts;

namespace TrainTicketBooking.Services
{
    public class PaymentService : IPaymentService
    {
        private readonly Random _random = new Random();

        public PaymentInfo ProcessPayment(decimal amount, PaymentMode mode)
        {
            var paymentInfo = new PaymentInfo
            {
                PaymentId = $"PAY-{DateTime.UtcNow:yyyyMMddHHmmssfff}",
                PaymentMode = mode,
                Amount = amount,
                PaymentDate = DateTime.Now
            };

            // Basic simulation with 95% success rate
            var isSuccess = _random.NextDouble() >= 0.05;
            if (isSuccess)
            {
                paymentInfo.Status = PaymentStatus.Completed;
                paymentInfo.TransactionId = $"TXN{_random.Next(100000, 999999)}";
            }
            else
            {
                paymentInfo.Status = PaymentStatus.Failed;
                paymentInfo.TransactionId = string.Empty;
            }

            return paymentInfo;
        }
    }
}

