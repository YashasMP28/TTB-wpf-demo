using TrainTicketBooking.Models;

namespace TrainTicketBooking.Services.Contracts
{
    public interface IPaymentService
    {
        PaymentInfo ProcessPayment(decimal amount, PaymentMode mode);
    }
}

