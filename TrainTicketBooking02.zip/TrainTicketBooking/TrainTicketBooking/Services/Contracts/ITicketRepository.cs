using System.Collections.Generic;
using TrainTicketBooking.MVVM;

namespace TrainTicketBooking.Services.Contracts
{
    public interface ITicketRepository
    {
        IEnumerable<Ticket> LoadTickets();
        void SaveTickets(IEnumerable<Ticket> tickets);
    }
}

