using System.Collections.Generic;
using TrainTicketBooking.Models;

namespace TrainTicketBooking.Services.Contracts
{
    public interface ITrainScheduleService
    {
        IEnumerable<TrainSchedule> GetSchedules();
        bool HasSeats(string trainNumber, string classType, int seatsRequested);
        bool TryReserveSeats(string trainNumber, string classType, int seatsRequested);
        void ReleaseSeats(string trainNumber, string classType, int seatsReleased);
        int GetAvailableSeats(string trainNumber, string classType);
    }
}

