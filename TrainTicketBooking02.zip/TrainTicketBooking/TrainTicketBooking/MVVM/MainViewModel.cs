﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Data;
using TrainTicketBooking.Data;
using TrainTicketBooking.Models;
using TrainTicketBooking.Services;
using TrainTicketBooking.Services.Contracts;

namespace TrainTicketBooking.MVVM
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private string _source;
        private string _destination;
        private DateTime _journeyDate = DateTime.Now.Date;
        private string _classType;
        private int _noOfTickets = 1;
        private string _trainname;
        private Ticket _selectedTicket;
        private string _passengerNameError;
        private string _passengerName;
        private int _passengerAge = 22;
        private string _passengerGender = "Male";
        private bool _isAboutPopupOpen;
        private string _successMessage;
        private bool _isSuccessMessageVisible;
        private PaymentMode _paymentMode = PaymentMode.Online;
        private decimal _calculatedFare;
        private string _pnrSearchText;
        private Ticket _pnrSearchResult;
        private bool _isLoginPopupOpen;
        private string _loginUsername;
        private string _loginPassword;
        private bool _isLoggedIn;
        private string _currentUserName;
        private TrainSchedule _selectedSchedule;
        private string _seatAvailabilityMessage;
        private string _historySearchText;
        private bool _isDialogOpen;
        private string _dialogTitle;
        private string _dialogMessage;
        private string _dialogPrimaryText = "OK";
        private string _dialogSecondaryText;
        private bool _isSecondaryButtonVisible;
        private Action _dialogPrimaryAction;
        private Action _dialogSecondaryAction;

        private readonly ITrainScheduleService _trainScheduleService;
        private readonly ITicketRepository _ticketRepository;
        private readonly IPaymentService _paymentService;
        private readonly HashSet<string> _generatedPnrs = new HashSet<string>();
        private readonly Random _random = new Random();
        private int _currentDistance;
        private bool _isUpdatingFromSchedule;

        public string PassengerName
        {
            get => _passengerName;
            set
            {
                if (_passengerName == value) return;

                if (string.IsNullOrWhiteSpace(value))
                {
                    _passengerName = string.Empty;
                    PassengerNameError = string.Empty;
                }
                else if (IsValidName(value))
                {
                    _passengerName = value;
                    PassengerNameError = string.Empty;
                }
                else
                {
                    PassengerNameError = "Only letters and spaces are allowed.";
                }

                OnPropertyChanged(nameof(PassengerName));
            }
        }

        public string PassengerNameError
        {
            get => _passengerNameError;
            set { _passengerNameError = value; OnPropertyChanged(nameof(PassengerNameError)); }
        }

        public string Source
        {
            get => _source;
            set 
            { 
                _source = value; 
                OnPropertyChanged(nameof(Source));
                OnPropertyChanged(nameof(SourceDestinationError));
                if (!_isUpdatingFromSchedule)
                {
                    _selectedSchedule = null;
                    _currentDistance = 0;
                    OnPropertyChanged(nameof(SelectedSchedule));
                }
                CalculateFare();
            }
        }

        public string Destination
        {
            get => _destination;
            set 
            { 
                _destination = value; 
                OnPropertyChanged(nameof(Destination));
                OnPropertyChanged(nameof(SourceDestinationError));
                if (!_isUpdatingFromSchedule)
                {
                    _selectedSchedule = null;
                    _currentDistance = 0;
                    OnPropertyChanged(nameof(SelectedSchedule));
                }
                CalculateFare();
            }
        }

        public string SourceDestinationError
        {
            get
            {
                if (!string.IsNullOrWhiteSpace(Source) && 
                    !string.IsNullOrWhiteSpace(Destination) &&
                    Source.Equals(Destination, StringComparison.OrdinalIgnoreCase))
                {
                    return "Source and destination cannot be the same.";
                }
                return string.Empty;
            }
        }

        public DateTime JourneyDate
        {
            get => _journeyDate;
            set 
            { 
                _journeyDate = value; 
                OnPropertyChanged(nameof(JourneyDate));
                CalculateFare();
            }
        }

        public string ClassType
        {
            get => _classType;
            set 
            { 
                _classType = value; 
                OnPropertyChanged(nameof(ClassType));
                CalculateFare();
                UpdateSeatAvailability();
            }
        }

        public string TrainName
        {
            get => _trainname;
            set { _trainname = value; OnPropertyChanged(nameof(TrainName)); }
        }

        public int NumberOfTickets
        {
            get => _noOfTickets;
            set 
            { 
                _noOfTickets = value <= 0 ? 1 : value; 
                OnPropertyChanged(nameof(NumberOfTickets));
                CalculateFare();
                UpdateSeatAvailability();
            }
        }

        public ObservableCollection<Ticket> Bookings { get; } = new ObservableCollection<Ticket>();
        public ObservableCollection<TrainSchedule> TrainSchedules { get; } = new ObservableCollection<TrainSchedule>();
        public ICollectionView BookingsView { get; }

        public Ticket SelectedTicket
        {
            get => _selectedTicket;
            set 
            { 
                _selectedTicket = value; 
                OnPropertyChanged(nameof(SelectedTicket));
                CommandManager.InvalidateRequerySuggested();
            }
        }

        public bool IsAboutPopupOpen
        {
            get => _isAboutPopupOpen;
            set { _isAboutPopupOpen = value; OnPropertyChanged(nameof(IsAboutPopupOpen)); }
        }

        public string SuccessMessage
        {
            get => _successMessage;
            set { _successMessage = value; OnPropertyChanged(nameof(SuccessMessage)); }
        }

        public bool IsSuccessMessageVisible
        {
            get => _isSuccessMessageVisible;
            set { _isSuccessMessageVisible = value; OnPropertyChanged(nameof(IsSuccessMessageVisible)); }
        }

        public int PassengerAge
        {
            get => _passengerAge;
            set
            {
                if (value < 0) value = 0;
                _passengerAge = value;
                OnPropertyChanged(nameof(PassengerAge));
            }
        }

        public string PassengerGender
        {
            get => _passengerGender;
            set { _passengerGender = value; OnPropertyChanged(nameof(PassengerGender)); }
        }

        public PaymentMode PaymentMode
        {
            get => _paymentMode;
            set { _paymentMode = value; OnPropertyChanged(nameof(PaymentMode)); }
        }

        public IEnumerable<PaymentMode> PaymentModes { get; } = Enum
            .GetValues(typeof(PaymentMode))
            .Cast<PaymentMode>();

        public decimal CalculatedFare
        {
            get => _calculatedFare;
            set { _calculatedFare = value; OnPropertyChanged(nameof(CalculatedFare)); }
        }

        public string PnrSearchText
        {
            get => _pnrSearchText;
            set
            {
                _pnrSearchText = value;
                OnPropertyChanged(nameof(PnrSearchText));
                CommandManager.InvalidateRequerySuggested();
            }
        }

        public Ticket PnrSearchResult
        {
            get => _pnrSearchResult;
            set { _pnrSearchResult = value; OnPropertyChanged(nameof(PnrSearchResult)); }
        }

        public bool IsLoginPopupOpen
        {
            get => _isLoginPopupOpen;
            set { _isLoginPopupOpen = value; OnPropertyChanged(nameof(IsLoginPopupOpen)); }
        }

        public string LoginUsername
        {
            get => _loginUsername;
            set { _loginUsername = value; OnPropertyChanged(nameof(LoginUsername)); }
        }

        public string LoginPassword
        {
            get => _loginPassword;
            set { _loginPassword = value; OnPropertyChanged(nameof(LoginPassword)); }
        }

        public bool IsLoggedIn
        {
            get => _isLoggedIn;
            set
            {
                _isLoggedIn = value;
                OnPropertyChanged(nameof(IsLoggedIn));
                OnPropertyChanged(nameof(IsNotLoggedIn));
                CommandManager.InvalidateRequerySuggested();
            }
        }

        public bool IsNotLoggedIn => !_isLoggedIn;

        public string CurrentUserName
        {
            get => _currentUserName;
            set { _currentUserName = value; OnPropertyChanged(nameof(CurrentUserName)); }
        }

        public TrainSchedule SelectedSchedule
        {
            get => _selectedSchedule;
            set
            {
                _selectedSchedule = value;
                OnPropertyChanged(nameof(SelectedSchedule));

                if (value != null)
                {
                    _isUpdatingFromSchedule = true;
                    Source = value.Source;
                    Destination = value.Destination;
                    TrainName = value.TrainName;
                    _currentDistance = value.DistanceInKm;
                    if (string.IsNullOrWhiteSpace(ClassType))
                    {
                        ClassType = value.SeatsByClass.Keys.FirstOrDefault();
                    }
                    _isUpdatingFromSchedule = false;
                }

                UpdateSeatAvailability();
                CalculateFare();
            }
        }

        public string SeatAvailabilityMessage
        {
            get => _seatAvailabilityMessage;
            set { _seatAvailabilityMessage = value; OnPropertyChanged(nameof(SeatAvailabilityMessage)); }
        }

        public string HistorySearchText
        {
            get => _historySearchText;
            set
            {
                _historySearchText = value;
                OnPropertyChanged(nameof(HistorySearchText));
                BookingsView?.Refresh();
            }
        }

        public bool IsDialogOpen
        {
            get => _isDialogOpen;
            set { _isDialogOpen = value; OnPropertyChanged(nameof(IsDialogOpen)); }
        }

        public string DialogTitle
        {
            get => _dialogTitle;
            set { _dialogTitle = value; OnPropertyChanged(nameof(DialogTitle)); }
        }

        public string DialogMessage
        {
            get => _dialogMessage;
            set { _dialogMessage = value; OnPropertyChanged(nameof(DialogMessage)); }
        }

        public string DialogPrimaryText
        {
            get => _dialogPrimaryText;
            set { _dialogPrimaryText = value; OnPropertyChanged(nameof(DialogPrimaryText)); }
        }

        public string DialogSecondaryText
        {
            get => _dialogSecondaryText;
            set { _dialogSecondaryText = value; OnPropertyChanged(nameof(DialogSecondaryText)); }
        }

        public bool IsSecondaryButtonVisible
        {
            get => _isSecondaryButtonVisible;
            set { _isSecondaryButtonVisible = value; OnPropertyChanged(nameof(IsSecondaryButtonVisible)); }
        }

        // Commands
        public ICommand BookTicketCommand { get; }
        public ICommand ClearAllTicketsCommand { get; }
        public ICommand LoadTicketsCommand { get; }
        public ICommand SaveTicketsCommand { get; }
        public ICommand OpenAboutPopupCommand { get; }
        public ICommand ClosePopupCommand { get; }
        public ICommand RemoveCommand { get; }
        public ICommand ShowConfirmationCommand { get; }
        public ICommand CancelTicketCommand { get; }
        public ICommand CheckPnrStatusCommand { get; }
        public ICommand LoginCommand { get; }
        public ICommand LogoutCommand { get; }
        public ICommand OpenLoginPopupCommand { get; }
        public ICommand RefreshSchedulesCommand { get; }
        public ICommand SearchHistoryCommand { get; }
        public ICommand DialogPrimaryCommand { get; }
        public ICommand DialogSecondaryCommand { get; }

        public MainViewModel()
        {
            _trainScheduleService = new TrainScheduleService();
            _ticketRepository = new JsonTicketRepository();
            _paymentService = new PaymentService();

            Bookings.CollectionChanged += (_, __) => CommandManager.InvalidateRequerySuggested();
            BookingsView = CollectionViewSource.GetDefaultView(Bookings);
            if (BookingsView != null)
            {
                BookingsView.Filter = FilterBookings;
            }

            LoadTicketsCommand = new RelayCommand(_ => LoadTickets());
            SaveTicketsCommand = new RelayCommand(_ => SaveTickets());
            RefreshSchedulesCommand = new RelayCommand(_ => LoadSchedules());

            BookTicketCommand = new RelayCommand(_ => BookTicket(), _ => CanBookTicket());
            ClearAllTicketsCommand = new RelayCommand(_ => RequestClearAllTickets(), _ => Bookings.Count > 0 && IsLoggedIn);
            RemoveCommand = new RelayCommand(_ => RemoveSelected(), _ => SelectedTicket != null);
            ShowConfirmationCommand = new RelayCommand(_ => ShowConfirmation(), _ => SelectedTicket != null);
            CancelTicketCommand = new RelayCommand(_ => RequestCancelTicket(), _ => SelectedTicket != null && SelectedTicket.Status != PnrStatus.Cancelled);
            CheckPnrStatusCommand = new RelayCommand(_ => CheckPnrStatus(), _ => !string.IsNullOrWhiteSpace(PnrSearchText));
            SearchHistoryCommand = new RelayCommand(_ => BookingsView?.Refresh());

            OpenAboutPopupCommand = new RelayCommand(_ => IsAboutPopupOpen = true);
            ClosePopupCommand = new RelayCommand(_ => IsAboutPopupOpen = false);
            OpenLoginPopupCommand = new RelayCommand(_ => IsLoginPopupOpen = true);
            LoginCommand = new RelayCommand(_ => Login(), _ => !string.IsNullOrWhiteSpace(LoginUsername) && !string.IsNullOrWhiteSpace(LoginPassword));
            LogoutCommand = new RelayCommand(_ => Logout(), _ => IsLoggedIn);

            DialogPrimaryCommand = new RelayCommand(_ => ExecuteDialogPrimaryAction(), _ => IsDialogOpen);
            DialogSecondaryCommand = new RelayCommand(_ => ExecuteDialogSecondaryAction(), _ => IsDialogOpen && IsSecondaryButtonVisible);

            LoadSchedules();
            LoadTickets();
            CalculateFare();
            UpdateSeatAvailability();
        }

        private bool IsValidName(string input) =>
            System.Text.RegularExpressions.Regex.IsMatch(input ?? string.Empty, "^[a-zA-Z ]+$");

        private bool CanBookTicket()
        {
            return IsLoggedIn &&
                   string.IsNullOrWhiteSpace(PassengerNameError) &&
                   !string.IsNullOrWhiteSpace(PassengerName) &&
                   !string.IsNullOrWhiteSpace(Source) &&
                   !string.IsNullOrWhiteSpace(Destination) &&
                   !string.IsNullOrWhiteSpace(TrainName) &&
                   !string.IsNullOrWhiteSpace(ClassType) &&
                   NumberOfTickets > 0 &&
                   JourneyDate >= DateTime.Now.Date &&
                   string.IsNullOrWhiteSpace(SourceDestinationError);
        }

        private void CalculateFare()
        {
            if (string.IsNullOrWhiteSpace(Source) ||
                string.IsNullOrWhiteSpace(Destination) ||
                string.IsNullOrWhiteSpace(ClassType) ||
                NumberOfTickets <= 0)
            {
                CalculatedFare = 0;
                return;
            }

            var distance = _currentDistance > 0
                ? _currentDistance
                : FareCalculator.CalculateDistance(Source, Destination);

            if (_selectedSchedule == null)
            {
                _currentDistance = distance;
            }

            CalculatedFare = FareCalculator.CalculateFare(ClassType, distance, JourneyDate, NumberOfTickets);
        }

        private void UpdateSeatAvailability()
        {
            if (SelectedSchedule == null || string.IsNullOrWhiteSpace(ClassType))
            {
                SeatAvailabilityMessage = "Select a train and class to view seat availability.";
                return;
            }

            var available = _trainScheduleService.GetAvailableSeats(SelectedSchedule.TrainNumber, ClassType);
            SeatAvailabilityMessage = available > 0
                ? $"{available} seats available in {ClassType}."
                : $"Waitlist in {ClassType}.";
        }

        private void LoadSchedules()
        {
            TrainSchedules.Clear();
            foreach (var schedule in _trainScheduleService.GetSchedules())
            {
                TrainSchedules.Add(schedule);
            }
        }

        private void BookTicket()
        {
            if (!CanBookTicket())
            {
                ShowValidationError();
                return;
            }

            var trainNumber = SelectedSchedule?.TrainNumber ?? GenerateTrainNumber(TrainName);
            if (!_trainScheduleService.HasSeats(trainNumber, ClassType, NumberOfTickets))
            {
                var available = _trainScheduleService.GetAvailableSeats(trainNumber, ClassType);
                ShowDialog("Insufficient Seats",
                    available > 0
                        ? $"Only {available} seats left in {ClassType}."
                        : $"No seats left in {ClassType}. Please choose another class or train.");
                return;
            }

            var fare = CalculatedFare;
            var paymentInfo = _paymentService.ProcessPayment(fare, PaymentMode);
            if (paymentInfo.Status != PaymentStatus.Completed)
            {
                ShowDialog("Payment Failed", "Payment could not be processed. Please try again.");
                return;
            }

            var pnr = GeneratePnr();
            var seatNumber = GenerateSeatNumber();

            var ticket = new Ticket
            {
                PassengerName = PassengerName,
                PassengerAge = PassengerAge,
                PassengerGender = PassengerGender,
                Source = Source,
                Destination = Destination,
                Date = JourneyDate,
                BookingDate = DateTime.Now,
                PNR = pnr,
                TrainName = TrainName,
                TrainNumber = trainNumber,
                ClassType = ClassType,
                NoOfTickets = NumberOfTickets,
                IsConfirmed = true,
                Status = PnrStatus.Confirmed,
                SeatNumber = seatNumber,
                Distance = _currentDistance,
                Fare = fare,
                PaymentInfo = paymentInfo,
                ViaStations = SelectedSchedule?.ViaStations?.ToList() ?? new List<string>()
            };

            ticket.Passengers.Add(new Passenger
            {
                Name = PassengerName,
                Age = PassengerAge,
                Gender = PassengerGender,
                SeatNumber = seatNumber
            });

            if (!_trainScheduleService.TryReserveSeats(trainNumber, ClassType, NumberOfTickets))
            {
                ShowDialog("Reservation Error", "Unable to reserve seats. Please try again.");
                return;
            }

            Bookings.Add(ticket);
            SaveTickets();
            ShowSuccessMessage($"Ticket booked successfully! PNR: {pnr} • Fare: ₹{fare:F2}");
            ClearForm();
            UpdateSeatAvailability();
        }

        private string GenerateTrainNumber(string trainName)
        {
            if (string.IsNullOrWhiteSpace(trainName))
            {
                return $"TRN{_random.Next(100, 999)}";
            }

            var prefix = new string(trainName.Where(char.IsLetter).Take(3).DefaultIfEmpty('T').ToArray())
                .ToUpperInvariant();
            return $"{prefix}{_random.Next(100, 999)}";
        }

        private void ShowValidationError()
        {
            ShowDialog("Validation Error", "Please fill all required fields correctly.");
        }

        private void ShowSuccessMessage(string message)
        {
            SuccessMessage = message;
            IsSuccessMessageVisible = true;
            
            // Auto-hide after 3 seconds
            var timer = new System.Windows.Threading.DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(3)
            };
            timer.Tick += (s, e) =>
            {
                IsSuccessMessageVisible = false;
                timer.Stop();
            };
            timer.Start();
        }

        private void ClearForm()
        {
            PassengerName = string.Empty;
            PassengerNameError = string.Empty;
            PassengerAge = 25;
            PassengerGender = "Male";
            _isUpdatingFromSchedule = true;
            Source = string.Empty;
            Destination = string.Empty;
            TrainName = string.Empty;
            _isUpdatingFromSchedule = false;
            SelectedSchedule = null;
            _currentDistance = 0;
            ClassType = string.Empty;
            NumberOfTickets = 1;
            JourneyDate = DateTime.Now.Date;
            PaymentMode = PaymentMode.Online;
            CalculateFare();
        }

        private void RequestCancelTicket()
        {
            if (SelectedTicket == null || SelectedTicket.Status == PnrStatus.Cancelled)
                return;

            var refund = RefundCalculator.CalculateRefund(SelectedTicket);
            ShowDialog(
                "Cancel Ticket",
                $"PNR: {SelectedTicket.PNR}\nRefund: ₹{refund.RefundableAmount:F2} ({refund.RefundPercentage}%)\nCharges: ₹{refund.CancellationCharges:F2}\n\nProceed with cancellation?",
                "Yes, cancel",
                () =>
                {
                    SelectedTicket.Status = PnrStatus.Cancelled;
                    SelectedTicket.IsConfirmed = false;
                    if (SelectedTicket.PaymentInfo == null)
                    {
                        SelectedTicket.PaymentInfo = new PaymentInfo();
                    }
                    SelectedTicket.PaymentInfo.Status = PaymentStatus.Refunded;
                    _trainScheduleService.ReleaseSeats(SelectedTicket.TrainNumber, SelectedTicket.ClassType, SelectedTicket.NoOfTickets);
                    SaveTickets();
                    ShowSuccessMessage($"Ticket cancelled. Refund: ₹{refund.RefundableAmount:F2}");
                    SelectedTicket = null;
                    UpdateSeatAvailability();
                },
                "No");
        }

        private void CheckPnrStatus()
        {
            if (string.IsNullOrWhiteSpace(PnrSearchText))
                return;

            var ticket = Bookings.FirstOrDefault(t =>
                !string.IsNullOrWhiteSpace(t?.PNR) &&
                t.PNR.Equals(PnrSearchText, StringComparison.OrdinalIgnoreCase));
            
            if (ticket != null)
            {
                PnrSearchResult = ticket;
                SelectedTicket = ticket;
                ShowSuccessMessage($"PNR Status: {ticket.Status} • Fare: ₹{ticket.Fare:F2}");
            }
            else
            {
                PnrSearchResult = null;
                ShowDialog("PNR Not Found", $"No booking found for PNR {PnrSearchText}.");
            }
        }

        private void Login()
        {
            if (string.IsNullOrWhiteSpace(LoginUsername) || string.IsNullOrWhiteSpace(LoginPassword))
            {
                ShowDialog("Login Failed", "Please enter username and password.");
                return;
            }

            if (AuthenticationService.Login(LoginUsername, LoginPassword))
            {
                IsLoggedIn = true;
                CurrentUserName = AuthenticationService.CurrentUser.FullName;
                IsLoginPopupOpen = false;
                LoginUsername = string.Empty;
                LoginPassword = string.Empty;
                ShowSuccessMessage($"Welcome, {CurrentUserName}!");
            }
            else
            {
                ShowDialog("Login Failed",
                    "Invalid credentials.\nTry user/user123 or admin/admin123.");
            }
        }

        private void Logout()
        {
            AuthenticationService.Logout();
            IsLoggedIn = false;
            CurrentUserName = string.Empty;
            ShowSuccessMessage("Logged out successfully.");
        }

        private void RequestClearAllTickets()
        {
            if (Bookings.Count == 0)
                return;

            ShowDialog(
                "Clear All Tickets",
                "Are you sure you want to remove all saved tickets?",
                "Yes, clear",
                () =>
                {
                    foreach (var ticket in Bookings.Where(t => t.Status != PnrStatus.Cancelled))
                    {
                        _trainScheduleService.ReleaseSeats(ticket.TrainNumber, ticket.ClassType, ticket.NoOfTickets);
                    }
                    Bookings.Clear();
                    SaveTickets();
                    ShowSuccessMessage("All tickets cleared successfully.");
                    UpdateSeatAvailability();
                },
                "No");
        }

        private void LoadTickets()
        {
            Bookings.Clear();
            foreach (var ticket in _ticketRepository.LoadTickets())
            {
                Bookings.Add(ticket);
                if (!string.IsNullOrWhiteSpace(ticket.PNR))
                {
                    _generatedPnrs.Add(ticket.PNR);
                }
            }

            BookingsView?.Refresh();
        }

        private void SaveTickets()
        {
            _ticketRepository.SaveTickets(Bookings.ToList());
        }

        private void RemoveSelected()
        {
            if (SelectedTicket == null)
                return;

            if (SelectedTicket.Status != PnrStatus.Cancelled)
            {
                _trainScheduleService.ReleaseSeats(SelectedTicket.TrainNumber, SelectedTicket.ClassType, SelectedTicket.NoOfTickets);
            }

            Bookings.Remove(SelectedTicket);
            SaveTickets();
            SelectedTicket = null;
            ShowSuccessMessage("Ticket removed successfully!");
            UpdateSeatAvailability();
        }

        private void ShowConfirmation()
        {
            if (SelectedTicket == null)
                return;
            var window = new ConfirmedTicketWindow(SelectedTicket);
            window.ShowDialog();
        }

        private string GeneratePnr()
        {
            string pnr;
            do
            {
                pnr = $"{DateTime.UtcNow:yyMMddHHmm}{_random.Next(100, 999)}";
            } while (_generatedPnrs.Contains(pnr));

            _generatedPnrs.Add(pnr);
            return pnr;
        }

        private string GenerateSeatNumber()
        {
            var seat = _random.Next(1, 180);
            return $"S{seat}";
        }

        private void ShowDialog(string title, string message, string primaryText = "OK", Action primaryAction = null, string secondaryText = null)
        {
            DialogTitle = title;
            DialogMessage = message;
            DialogPrimaryText = primaryText;
            DialogSecondaryText = secondaryText;
            IsSecondaryButtonVisible = !string.IsNullOrWhiteSpace(secondaryText);

            _dialogPrimaryAction = () =>
            {
                primaryAction?.Invoke();
                CloseDialog();
            };

            _dialogSecondaryAction = () =>
            {
                CloseDialog();
            };

            IsDialogOpen = true;
        }

        private void CloseDialog()
        {
            IsDialogOpen = false;
            IsSecondaryButtonVisible = false;
            DialogSecondaryText = string.Empty;
            _dialogPrimaryAction = null;
            _dialogSecondaryAction = null;
        }

        private void ExecuteDialogPrimaryAction() => _dialogPrimaryAction?.Invoke();

        private void ExecuteDialogSecondaryAction() => _dialogSecondaryAction?.Invoke();

        private bool FilterBookings(object obj)
        {
            if (string.IsNullOrWhiteSpace(HistorySearchText))
                return true;

            var ticket = obj as Ticket;
            if (ticket == null)
                return false;

            var query = HistorySearchText.Trim();
            return ContainsInvariant(ticket.PNR, query) ||
                   ContainsInvariant(ticket.PassengerName, query) ||
                   ContainsInvariant(ticket.Source, query) ||
                   ContainsInvariant(ticket.Destination, query);
        }

        private static bool ContainsInvariant(string source, string value)
        {
            return !string.IsNullOrWhiteSpace(source) &&
                   !string.IsNullOrWhiteSpace(value) &&
                   source.IndexOf(value, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
