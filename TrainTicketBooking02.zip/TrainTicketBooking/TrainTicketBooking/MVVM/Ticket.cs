﻿using System;
using System.Collections.Generic;
using TrainTicketBooking.Models;

namespace TrainTicketBooking.MVVM
{
    public class Ticket
    {
        // Primary Passenger (for backward compatibility)
        public string PassengerName { get; set; }
        public int PassengerAge { get; set; } = 22;
        public string PassengerGender { get; set; } = "Male";
        
        // Journey Details
        public string Source { get; set; }
        public string Destination { get; set; }
        public DateTime Date { get; set; }
        public DateTime BookingDate { get; set; }
        
        // Ticket Details
        public string PNR { get; set; }
        public string TrainName { get; set; }
        public string TrainNumber { get; set; }
        public string ClassType { get; set; }
        public int NoOfTickets { get; set; }
        
        // Status and Seat
        public bool IsConfirmed { get; set; }
        public PnrStatus Status { get; set; }
        public string SeatNumber { get; set; }
        public List<string> ViaStations { get; set; }
        
        // Multiple Passengers Support
        public List<Passenger> Passengers { get; set; }
        
        // Payment and Fare
        public decimal Fare { get; set; }
        public PaymentInfo PaymentInfo { get; set; }
        
        // Distance (for fare calculation)
        public int Distance { get; set; } // in kilometers

        public Ticket()
        {
            Passengers = new List<Passenger>();
            ViaStations = new List<string>();
            BookingDate = DateTime.Now;
            Status = PnrStatus.Confirmed;
            IsConfirmed = true;
        }

        public override string ToString()
        {
            var passengerLabel = string.IsNullOrWhiteSpace(PassengerName)
                ? "Passenger"
                : PassengerName;

            var dateLabel = Date == default ? "N/A" : Date.ToShortDateString();
            var trainLabel = string.IsNullOrWhiteSpace(TrainName) ? "Train" : TrainName;

            return $"{passengerLabel} ({PassengerAge}, {PassengerGender}) - {Source} to {Destination} on {dateLabel} via {trainLabel} ({ClassType}) • PNR: {PNR} • Status: {Status}";
        }
    }
}
