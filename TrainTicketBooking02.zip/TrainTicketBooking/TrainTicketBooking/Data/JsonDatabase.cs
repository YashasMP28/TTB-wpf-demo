﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using Newtonsoft.Json;
using TrainTicketBooking.MVVM;
using TrainTicketBooking.Services.Contracts;

namespace TrainTicketBooking.Data
{
    public class JsonTicketRepository : ITicketRepository
    {
        private readonly string _filePath;
        private readonly object _lockObj = new object();

        public JsonTicketRepository()
        {
            var appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            var directory = Path.Combine(appData, "TrainTicketBooking");
            if (!Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }

            _filePath = Path.Combine(directory, "tickets.json");
        }

        public IEnumerable<Ticket> LoadTickets()
        {
            try
            {
                if (!File.Exists(_filePath))
                {
                    return new List<Ticket>();
                }

                lock (_lockObj)
                {
                    var json = File.ReadAllText(_filePath);
                    var tickets = JsonConvert.DeserializeObject<List<Ticket>>(json) ?? new List<Ticket>();
                    foreach (var ticket in tickets)
                    {
                        if (ticket.Passengers == null)
                        {
                            ticket.Passengers = new List<Models.Passenger>();
                        }

                        if (ticket.ViaStations == null)
                        {
                            ticket.ViaStations = new List<string>();
                        }
                    }
                    return tickets;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Failed to load tickets: {ex}");
                return new List<Ticket>();
            }
        }

        public void SaveTickets(IEnumerable<Ticket> tickets)
        {
            try
            {
                var json = JsonConvert.SerializeObject(tickets, Formatting.Indented);
                lock (_lockObj)
                {
                    File.WriteAllText(_filePath, json);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Failed to save tickets: {ex}");
            }
        }
    }
}
