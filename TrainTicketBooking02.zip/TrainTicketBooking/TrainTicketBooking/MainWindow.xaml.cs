using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using TrainTicketBooking.MVVM;
using TrainTicketBooking.Theme;

namespace TrainTicketBooking
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = new MainViewModel();
            
            // Initialize theme toggle state after component is loaded
            this.Loaded += MainWindow_Loaded;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            // Initialize theme toggle state
            if (ThemeToggle != null)
            {
                ThemeToggle.IsChecked = ThemeManager.CurrentTheme == ThemeMode.Dark;
            }
        }

        private void ThemeToggle_Checked(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ThemeToggle != null && ThemeToggle.IsChecked == true)
                {
                    ThemeManager.CurrentTheme = ThemeMode.Dark;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Theme toggle error: {ex.Message}");
            }
        }

        private void ThemeToggle_Unchecked(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ThemeToggle != null && ThemeToggle.IsChecked == false)
                {
                    ThemeManager.CurrentTheme = ThemeMode.Light;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Theme toggle error: {ex.Message}");
            }
        }

        private void MinimizeButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                e.Handled = true;
                this.WindowState = WindowState.Minimized;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Minimize error: {ex.Message}");
            }
        }

        private void MaximizeButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                e.Handled = true;
                if (this.WindowState == WindowState.Maximized)
                {
                    this.WindowState = WindowState.Normal;
                }
                else
                {
                    this.WindowState = WindowState.Maximized;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Maximize error: {ex.Message}");
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                e.Handled = true;
                this.Close();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Close error: {ex.Message}");
            }
        }

        private void LoginPasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (sender is PasswordBox passwordBox && DataContext is MainViewModel vm)
            {
                vm.LoginPassword = passwordBox.Password;
                CommandManager.InvalidateRequerySuggested();
            }
        }

        private void CloseLoginPopup_Click(object sender, RoutedEventArgs e)
        {
            if (DataContext is MainViewModel vm)
            {
                vm.IsLoginPopupOpen = false;
                vm.LoginUsername = "";
                vm.LoginPassword = "";
                var passwordBox = this.FindName("LoginPasswordBox") as System.Windows.Controls.PasswordBox;
                if (passwordBox != null)
                {
                    passwordBox.Password = "";
                }
            }
        }
    }
}
