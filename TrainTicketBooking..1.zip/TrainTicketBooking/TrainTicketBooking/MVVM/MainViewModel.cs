﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq; 
using System.Windows;
using System.Windows.Input;
using TrainTicketBooking.Data;
using TrainTicketBooking.Services;
using TrainTicketBooking.Models;

namespace TrainTicketBooking.MVVM
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private string _source;
        private string _destination;
        private DateTime _journeyDate = DateTime.Now.Date;
        private string _classType;
        private int _noOfTickets = 1;
        private string _trainname;
        private Ticket _selectedTicket;
        private string _passengerNameError;
        private string _passengerName;
        private int _passengerAge = 25;
        private string _passengerGender = "Male";
        private bool _isAboutPopupOpen;
        private string _successMessage;
        private bool _isSuccessMessageVisible;
        private PaymentMode _paymentMode = PaymentMode.Online;
        private decimal _calculatedFare;
        private string _pnrSearchText;
        private Ticket _pnrSearchResult;
        private bool _isLoginPopupOpen;
        private string _loginUsername;
        private string _loginPassword;
        private bool _isLoggedIn;
        private string _currentUserName;

        public string PassengerName
        {
            get => _passengerName;
            set
            {
                if (_passengerName == value) return;

                if (string.IsNullOrWhiteSpace(value))
                {
                    _passengerName = string.Empty;
                    PassengerNameError = string.Empty;
                }
                else if (IsValidName(value))
                {
                    _passengerName = value;
                    PassengerNameError = string.Empty;
                }
                else
                {
                    PassengerNameError = "Only letters and spaces are allowed.";
                }

                OnPropertyChanged(nameof(PassengerName));
            }
        }

        public string PassengerNameError
        {
            get => _passengerNameError;
            set { _passengerNameError = value; OnPropertyChanged(nameof(PassengerNameError)); }
        }

        public string Source
        {
            get => _source;
            set 
            { 
                _source = value; 
                OnPropertyChanged(nameof(Source));
                OnPropertyChanged(nameof(SourceDestinationError));
                CalculateFare();
            }
        }

        public string Destination
        {
            get => _destination;
            set 
            { 
                _destination = value; 
                OnPropertyChanged(nameof(Destination));
                OnPropertyChanged(nameof(SourceDestinationError));
                CalculateFare();
            }
        }

        public string SourceDestinationError
        {
            get
            {
                if (!string.IsNullOrWhiteSpace(Source) && 
                    !string.IsNullOrWhiteSpace(Destination) &&
                    Source.Equals(Destination, StringComparison.OrdinalIgnoreCase))
                {
                    return "Source and destination cannot be the same.";
                }
                return string.Empty;
            }
        }

        public DateTime JourneyDate
        {
            get => _journeyDate;
            set 
            { 
                _journeyDate = value; 
                OnPropertyChanged(nameof(JourneyDate));
                CalculateFare();
            }
        }

        public string ClassType
        {
            get => _classType;
            set 
            { 
                _classType = value; 
                OnPropertyChanged(nameof(ClassType));
                CalculateFare();
            }
        }

        public string TrainName
        {
            get => _trainname;
            set { _trainname = value; OnPropertyChanged(nameof(TrainName)); }
        }

        public int NumberOfTickets
        {
            get => _noOfTickets;
            set 
            { 
                _noOfTickets = value; 
                OnPropertyChanged(nameof(NumberOfTickets));
                CalculateFare();
            }
        }

        public ObservableCollection<Ticket> Bookings { get; } = new ObservableCollection<Ticket>();

        public Ticket SelectedTicket
        {
            get => _selectedTicket;
            set 
            { 
                _selectedTicket = value; 
                OnPropertyChanged(nameof(SelectedTicket));
                CommandManager.InvalidateRequerySuggested();
            }
        }

        public bool IsAboutPopupOpen
        {
            get => _isAboutPopupOpen;
            set { _isAboutPopupOpen = value; OnPropertyChanged(nameof(IsAboutPopupOpen)); }
        }

        public string SuccessMessage
        {
            get => _successMessage;
            set { _successMessage = value; OnPropertyChanged(nameof(SuccessMessage)); }
        }

        public bool IsSuccessMessageVisible
        {
            get => _isSuccessMessageVisible;
            set { _isSuccessMessageVisible = value; OnPropertyChanged(nameof(IsSuccessMessageVisible)); }
        }

        public int PassengerAge
        {
            get => _passengerAge;
            set 
            { 
                _passengerAge = value; 
                OnPropertyChanged(nameof(PassengerAge));
                CalculateFare();
            }
        }

        public string PassengerGender
        {
            get => _passengerGender;
            set { _passengerGender = value; OnPropertyChanged(nameof(PassengerGender)); }
        }

        public PaymentMode PaymentMode
        {
            get => _paymentMode;
            set { _paymentMode = value; OnPropertyChanged(nameof(PaymentMode)); }
        }

        public decimal CalculatedFare
        {
            get => _calculatedFare;
            set { _calculatedFare = value; OnPropertyChanged(nameof(CalculatedFare)); }
        }

        public string PnrSearchText
        {
            get => _pnrSearchText;
            set 
            { 
                _pnrSearchText = value; 
                OnPropertyChanged(nameof(PnrSearchText));
                CommandManager.InvalidateRequerySuggested();
            }
        }

        public Ticket PnrSearchResult
        {
            get => _pnrSearchResult;
            set { _pnrSearchResult = value; OnPropertyChanged(nameof(PnrSearchResult)); }
        }

        public bool IsLoginPopupOpen
        {
            get => _isLoginPopupOpen;
            set { _isLoginPopupOpen = value; OnPropertyChanged(nameof(IsLoginPopupOpen)); }
        }

        public string LoginUsername
        {
            get => _loginUsername;
            set { _loginUsername = value; OnPropertyChanged(nameof(LoginUsername)); }
        }

        public string LoginPassword
        {
            get => _loginPassword;
            set { _loginPassword = value; OnPropertyChanged(nameof(LoginPassword)); }
        }

        public bool IsLoggedIn
        {
            get => _isLoggedIn;
            set 
            { 
                _isLoggedIn = value; 
                OnPropertyChanged(nameof(IsLoggedIn));
                OnPropertyChanged(nameof(IsNotLoggedIn));
                CommandManager.InvalidateRequerySuggested();
            }
        }

        public bool IsNotLoggedIn => !_isLoggedIn;

        public string CurrentUserName
        {
            get => _currentUserName;
            set { _currentUserName = value; OnPropertyChanged(nameof(CurrentUserName)); }
        }

        // Commands
        public ICommand BookTicketCommand { get; }
        public ICommand ClearAllTicketsCommand { get; }
        public ICommand LoadTicketsCommand { get; }
        public ICommand SaveTicketsCommand { get; }
        public ICommand OpenAboutPopupCommand { get; }
        public ICommand ClosePopupCommand { get; }
        public ICommand RemoveCommand { get; }
        public ICommand ShowConfirmationCommand { get; }
        public ICommand CancelTicketCommand { get; }
        public ICommand CheckPnrStatusCommand { get; }
        public ICommand LoginCommand { get; }
        public ICommand LogoutCommand { get; }
        public ICommand OpenLoginPopupCommand { get; }

        public MainViewModel()
        {
            LoadTicketsCommand = new RelayCommand(_ => LoadTickets());
            BookTicketCommand = new RelayCommand(_ => BookTicket(), _ => CanBookTicket() && IsLoggedIn);
            ClearAllTicketsCommand = new RelayCommand(_ => ClearAllTickets(), _ => Bookings.Count > 0 && IsLoggedIn);
            SaveTicketsCommand = new RelayCommand(_ => SaveTickets());
            OpenAboutPopupCommand = new RelayCommand(_ => IsAboutPopupOpen = true);
            ClosePopupCommand = new RelayCommand(_ => IsAboutPopupOpen = false);
            RemoveCommand = new RelayCommand(_ => RemoveSelected(), _ => SelectedTicket != null);
            ShowConfirmationCommand = new RelayCommand(_ => ShowConfirmation(), _ => SelectedTicket != null);
            CancelTicketCommand = new RelayCommand(_ => CancelTicket(), _ => SelectedTicket != null && SelectedTicket.Status != PnrStatus.Cancelled);
            CheckPnrStatusCommand = new RelayCommand(_ => CheckPnrStatus(), _ => !string.IsNullOrWhiteSpace(PnrSearchText));
            LoginCommand = new RelayCommand(_ => Login(), _ => !string.IsNullOrWhiteSpace(LoginUsername) && !string.IsNullOrWhiteSpace(LoginPassword));
            LogoutCommand = new RelayCommand(_ => Logout());
            OpenLoginPopupCommand = new RelayCommand(_ => IsLoginPopupOpen = true);

            // Load tickets on startup
            LoadTickets();
            
            // Calculate initial fare
            CalculateFare();
        }

        private bool IsValidName(string input)
        {
            return System.Text.RegularExpressions.Regex.IsMatch(input, "^[a-zA-Z ]+$");
        }

        private bool CanBookTicket()
        {
            return !string.IsNullOrWhiteSpace(PassengerName) &&
                   !string.IsNullOrWhiteSpace(Source) &&
                   !string.IsNullOrWhiteSpace(Destination) &&
                   !string.IsNullOrWhiteSpace(TrainName) &&
                   JourneyDate >= DateTime.Now.Date &&
                   string.IsNullOrWhiteSpace(SourceDestinationError);
        }

        private void CalculateFare()
        {
            if (string.IsNullOrWhiteSpace(Source) || string.IsNullOrWhiteSpace(Destination) || 
                string.IsNullOrWhiteSpace(ClassType) || NumberOfTickets <= 0)
            {
                CalculatedFare = 0;
                return;
            }

            var distance = FareCalculator.CalculateDistance(Source, Destination);
            CalculatedFare = FareCalculator.CalculateFare(ClassType, distance, JourneyDate, NumberOfTickets);
        }

        private void BookTicket()
        {
            if (!CanBookTicket())
            {
                ShowValidationError();
                return;
            }

            if (!IsLoggedIn)
            {
                MessageBox.Show("Please login to book tickets.", "Login Required", 
                    MessageBoxButton.OK, MessageBoxImage.Information);
                IsLoginPopupOpen = true;
                return;
            }

            var distance = FareCalculator.CalculateDistance(Source, Destination);
            var fare = FareCalculator.CalculateFare(ClassType, distance, JourneyDate, NumberOfTickets);
            var pnr = GeneratePNR();
            var seatNumber = GenerateSeatNumber();

            // Create payment info
            var paymentInfo = new PaymentInfo
            {
                PaymentId = $"PAY{DateTime.Now:yyyyMMddHHmmss}",
                PaymentMode = PaymentMode,
                Status = PaymentStatus.Completed,
                Amount = fare,
                PaymentDate = DateTime.Now,
                TransactionId = $"TXN{new Random().Next(100000, 999999)}"
            };

            var ticket = new Ticket
            {
                PassengerName = PassengerName,
                PassengerAge = PassengerAge,
                PassengerGender = PassengerGender,
                Source = Source,
                Destination = Destination,
                Date = JourneyDate,
                BookingDate = DateTime.Now,
                PNR = pnr,
                TrainName = TrainName,
                TrainCode = GenerateTrainCode(TrainName),
                ClassType = ClassType,
                NoOfTickets = NumberOfTickets,
                IsConfirmed = true,
                Status = PnrStatus.Confirmed,
                SeatNumber = seatNumber,
                Distance = distance,
                Fare = fare,
                PaymentInfo = paymentInfo
            };

            // Add primary passenger
            ticket.Passengers.Add(new Models.Passenger
            {
                Name = PassengerName,
                Age = PassengerAge,
                Gender = PassengerGender,
                SeatNumber = seatNumber
            });

            Bookings.Add(ticket);
            SaveTickets();
            ShowSuccessMessage($"Ticket booked successfully! PNR: {pnr} | Fare: ₹{fare:F2}");
            ClearForm();
        }

        private string GenerateTrainCode(string trainName)
        {
            if (string.IsNullOrWhiteSpace(trainName)) return "TRN001";
            var words = trainName.Split(' ');
            if (words.Length > 0)
            {
                return words[0].Substring(0, Math.Min(3, words[0].Length)).ToUpper() + 
                       new Random().Next(100, 999).ToString();
            }
            return "TRN" + new Random().Next(100, 999).ToString();
        }

        private void ShowValidationError()
        {
            // Trigger shake animation will be handled by validation rules
            MessageBox.Show("Please fill all required fields correctly.", "Validation Error", 
                MessageBoxButton.OK, MessageBoxImage.Warning);
        }

        private void ShowSuccessMessage(string message)
        {
            SuccessMessage = message;
            IsSuccessMessageVisible = true;
            
            // Auto-hide after 3 seconds
            var timer = new System.Windows.Threading.DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(3)
            };
            timer.Tick += (s, e) =>
            {
                IsSuccessMessageVisible = false;
                timer.Stop();
            };
            timer.Start();
        }

        private void ClearForm()
        {
            PassengerName = "";
            PassengerNameError = "";
            PassengerAge = 25;
            PassengerGender = "Male";
            Source = "";
            Destination = "";
            TrainName = "";
            ClassType = "";
            NumberOfTickets = 1;
            JourneyDate = DateTime.Now.Date;
            PaymentMode = PaymentMode.Online;
            CalculateFare();
        }

        private void CancelTicket()
        {
            if (SelectedTicket == null || SelectedTicket.Status == PnrStatus.Cancelled)
                return;

            var refund = RefundCalculator.CalculateRefund(SelectedTicket);
            
            var result = MessageBox.Show(
                $"Cancel this ticket?\n\n" +
                $"PNR: {SelectedTicket.PNR}\n" +
                $"Fare: ₹{SelectedTicket.Fare:F2}\n" +
                $"Refund: ₹{refund.RefundableAmount:F2} ({refund.RefundPercentage}%)\n" +
                $"Cancellation Charges: ₹{refund.CancellationCharges:F2}\n\n" +
                $"Reason: {refund.Reason}\n\n" +
                $"Do you want to proceed?",
                "Cancel Ticket",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                SelectedTicket.Status = PnrStatus.Cancelled;
                SelectedTicket.IsConfirmed = false;
                if (SelectedTicket.PaymentInfo != null)
                {
                    SelectedTicket.PaymentInfo.Status = PaymentStatus.Refunded;
                }
                SaveTickets();
                ShowSuccessMessage($"Ticket cancelled. Refund: ₹{refund.RefundableAmount:F2}");
                SelectedTicket = null;
            }
        }

        private void CheckPnrStatus()
        {
            if (string.IsNullOrWhiteSpace(PnrSearchText))
                return;

            var ticket = Bookings.FirstOrDefault(t => t.PNR.Equals(PnrSearchText, StringComparison.OrdinalIgnoreCase));
            
            if (ticket != null)
            {
                PnrSearchResult = ticket;
                SelectedTicket = ticket;
                ShowSuccessMessage($"PNR Status: {ticket.Status} | Fare: ₹{ticket.Fare:F2}");
            }
            else
            {
                PnrSearchResult = null;
                MessageBox.Show($"PNR {PnrSearchText} not found.", "PNR Not Found", 
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void Login()
        {
            if (string.IsNullOrWhiteSpace(LoginUsername) || string.IsNullOrWhiteSpace(LoginPassword))
            {
                MessageBox.Show("Please enter username and password.", "Login Failed", 
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (AuthenticationService.Login(LoginUsername, LoginPassword))
            {
                IsLoggedIn = true;
                CurrentUserName = AuthenticationService.CurrentUser.FullName;
                IsLoginPopupOpen = false;
                LoginUsername = "";
                LoginPassword = "";
                ShowSuccessMessage($"Welcome, {CurrentUserName}!");
            }
            else
            {
                MessageBox.Show("Invalid username or password.\n\nDefault credentials:\nUsername: user, Password: user123\nUsername: admin, Password: admin123", 
                    "Login Failed", 
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Logout()
        {
            AuthenticationService.Logout();
            IsLoggedIn = false;
            CurrentUserName = "";
            ShowSuccessMessage("Logged out successfully.");
        }

        private void ClearAllTickets()
        {
            var result = MessageBox.Show(
                "Are you sure you want to clear all tickets? This action cannot be undone.",
                "Confirm Clear All",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                Bookings.Clear();
                SaveTickets();
                ShowSuccessMessage("All tickets cleared successfully!");
            }
        }

        private void LoadTickets()
        {
            Bookings.Clear();
            var savedTickets = JsonDatabase.LoadTickets();
            foreach (var t in savedTickets)
                Bookings.Add(t);
        }

        private void SaveTickets()
        {
            JsonDatabase.SaveTickets(Bookings.ToList());
        }

        private void RemoveSelected()
        {
            if (SelectedTicket != null)
            {
                Bookings.Remove(SelectedTicket);
                SaveTickets();
                SelectedTicket = null;
                ShowSuccessMessage("Ticket removed successfully!");
            }
        }

        private void ShowConfirmation()
        {
            if (SelectedTicket == null)
                return;
            var window = new ConfirmedTicketWindow(SelectedTicket);
            window.ShowDialog();
        }

        private string GeneratePNR()
        {
            var random = new Random();
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, 10)
                .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        private string GenerateSeatNumber()
        {
            var random = new Random();
            int seat = random.Next(1, 72); 
            return "S" + seat.ToString();
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
