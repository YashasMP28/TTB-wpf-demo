using System;
using TrainTicketBooking.MVVM;

namespace TrainTicketBooking.Services
{
    public static class RefundCalculator
    {
        public static RefundResult CalculateRefund(Ticket ticket)
        {
            if (ticket == null || ticket.PaymentInfo == null)
                return new RefundResult { RefundableAmount = 0, RefundPercentage = 0 };

            var daysUntilJourney = (ticket.Date.Date - DateTime.Now.Date).Days;
            decimal refundPercentage = 0;
            string reason = "";

            // Refund rules based on cancellation time before journey
            if (daysUntilJourney >= 30)
            {
                refundPercentage = 100m; // Full refund
                reason = "Cancelled 30+ days before journey";
            }
            else if (daysUntilJourney >= 15)
            {
                refundPercentage = 75m; // 75% refund
                reason = "Cancelled 15-29 days before journey";
            }
            else if (daysUntilJourney >= 7)
            {
                refundPercentage = 50m; // 50% refund
                reason = "Cancelled 7-14 days before journey";
            }
            else if (daysUntilJourney >= 3)
            {
                refundPercentage = 25m; // 25% refund
                reason = "Cancelled 3-6 days before journey";
            }
            else if (daysUntilJourney >= 1)
            {
                refundPercentage = 10m; // 10% refund
                reason = "Cancelled 1-2 days before journey";
            }
            else
            {
                refundPercentage = 0m; // No refund
                reason = "Cancelled on journey date or after - No refund";
            }

            // Additional charges for certain classes
            decimal cancellationCharges = 0;
            if (ticket.ClassType.Contains("AC"))
            {
                cancellationCharges = 50; // AC class cancellation charge
            }

            decimal refundableAmount = (ticket.Fare * refundPercentage / 100) - cancellationCharges;
            if (refundableAmount < 0) refundableAmount = 0;

            return new RefundResult
            {
                RefundableAmount = Math.Round(refundableAmount, 2),
                RefundPercentage = refundPercentage,
                CancellationCharges = cancellationCharges,
                Reason = reason
            };
        }
    }

    public class RefundResult
    {
        public decimal RefundableAmount { get; set; }
        public decimal RefundPercentage { get; set; }
        public decimal CancellationCharges { get; set; }
        public string Reason { get; set; }
    }
}

