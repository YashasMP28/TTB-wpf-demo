using System;
using System.Collections.Generic;

namespace TrainTicketBooking.Services
{
    public static class FareCalculator
    {
        // Base fare per kilometer by class
        private static readonly decimal BaseFarePerKm_General = 0.5m;
        private static readonly decimal BaseFarePerKm_Sleeper = 1.0m;
        private static readonly decimal BaseFarePerKm_AC3Tier = 2.0m;
        private static readonly decimal BaseFarePerKm_AC2Tier = 3.0m;

        // Distance-based multipliers
        private static decimal GetDistanceMultiplier(int distance)
        {
            if (distance <= 100) return 1.0m;
            if (distance <= 500) return 0.9m;
            if (distance <= 1000) return 0.85m;
            return 0.8m; // Long distance discount
        }

        // Date-based pricing (peak season multiplier)
        private static decimal GetDateMultiplier(DateTime journeyDate)
        {
            var daysUntilJourney = (journeyDate.Date - DateTime.Now.Date).Days;
            
            // Peak season (holidays, festivals)
            var month = journeyDate.Month;
            if (month == 12 || month == 1 || month == 4 || month == 5) // Dec, Jan, Apr, May
                return 1.2m;
            
            // Advance booking discount
            if (daysUntilJourney >= 30) return 0.9m;
            if (daysUntilJourney >= 15) return 0.95m;
            
            // Last minute booking premium
            if (daysUntilJourney <= 1) return 1.15m;
            
            return 1.0m;
        }

        public static decimal CalculateFare(string classType, int distance, DateTime journeyDate, int numberOfTickets)
        {
            decimal baseFarePerKm = BaseFarePerKm_General;
            if (classType == "Sleeper")
                baseFarePerKm = BaseFarePerKm_Sleeper;
            else if (classType == "AC 3 Tier")
                baseFarePerKm = BaseFarePerKm_AC3Tier;
            else if (classType == "AC 2 Tier")
                baseFarePerKm = BaseFarePerKm_AC2Tier;

            var distanceMultiplier = GetDistanceMultiplier(distance);
            var dateMultiplier = GetDateMultiplier(journeyDate);

            decimal farePerTicket = baseFarePerKm * distance * distanceMultiplier * dateMultiplier;
            
            // Minimum fare
            if (farePerTicket < 50) farePerTicket = 50;

            return Math.Round(farePerTicket * numberOfTickets, 2);
        }

        public static int CalculateDistance(string source, string destination)
        {
            // Sample distances (in km) - simplified
            var distances = new Dictionary<(string, string), int>
            {
                { ("Chennai", "Bengaluru"), 350 },
                { ("Bengaluru", "Mumbai"), 850 },
                { ("Mumbai", "Hyderabad"), 700 },
                { ("Bengaluru", "Mysuru"), 140 },
                { ("Bengaluru", "Hubballi"), 470 },
                { ("Hubballi", "Mangaluru"), 300 },
                { ("Mysuru", "Mangaluru"), 220 },
                { ("Bengaluru", "Hyderabad"), 570 },
                { ("Chennai", "Hyderabad"), 715 },
                { ("Mumbai", "Bengaluru"), 850 }
            };

            // Check direct distance
            if (distances.ContainsKey((source, destination)))
                return distances[(source, destination)];
            if (distances.ContainsKey((destination, source)))
                return distances[(destination, source)];

            // Default: estimate based on station count (simplified)
            return 200; // Default distance
        }
    }
}

