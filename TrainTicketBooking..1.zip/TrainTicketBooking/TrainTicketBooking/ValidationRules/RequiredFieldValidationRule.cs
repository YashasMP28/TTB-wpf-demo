using System.Globalization;
using System.Windows.Controls;

namespace TrainTicketBooking.ValidationRules
{
    public class RequiredFieldValidationRule : ValidationRule
    {
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            if (value is string str && string.IsNullOrWhiteSpace(str))
            {
                return new ValidationResult(false, "This field is required.");
            }

            return ValidationResult.ValidResult;
        }
    }
}

