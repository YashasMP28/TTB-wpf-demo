using System.Globalization;
using System.Text.RegularExpressions;
using System.Windows.Controls;

namespace TrainTicketBooking.ValidationRules
{
    public class AlphabetsOnlyValidationRule : ValidationRule
    {
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            if (value is string str)
            {
                if (string.IsNullOrWhiteSpace(str))
                {
                    return ValidationResult.ValidResult; // Empty is handled by RequiredFieldValidationRule
                }

                if (!Regex.IsMatch(str, "^[a-zA-Z ]+$"))
                {
                    return new ValidationResult(false, "Only alphabets and spaces are allowed.");
                }
            }

            return ValidationResult.ValidResult;
        }
    }
}

