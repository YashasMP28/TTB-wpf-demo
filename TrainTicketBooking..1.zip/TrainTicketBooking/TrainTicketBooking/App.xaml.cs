using System.Windows;
using TrainTicketBooking.Theme;

namespace TrainTicketBooking
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            // Initialize theme after application resources are loaded
            this.Dispatcher.BeginInvoke(new System.Action(() =>
            {
                ThemeManager.CurrentTheme = ThemeMode.Light;
            }), System.Windows.Threading.DispatcherPriority.Loaded);
        }
    }
}
