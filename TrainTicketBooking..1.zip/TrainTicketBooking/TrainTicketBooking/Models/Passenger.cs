using System;

namespace TrainTicketBooking.Models
{
    public class Passenger
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; } // Male, Female, Other
        public string SeatNumber { get; set; }
    }
}

