using System;

namespace TrainTicketBooking.Models
{
    public enum PaymentMode
    {
        Online,
        Offline
    }

    public enum PaymentStatus
    {
        Pending,
        Completed,
        Failed,
        Refunded
    }

    public class PaymentInfo
    {
        public string PaymentId { get; set; }
        public PaymentMode PaymentMode { get; set; }
        public PaymentStatus Status { get; set; }
        public decimal Amount { get; set; }
        public DateTime PaymentDate { get; set; }
        public string TransactionId { get; set; }
    }
}

