﻿using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using TrainTicketBooking.MVVM;

namespace TrainTicketBooking.Data
{
    public static class JsonDatabase
    {
        private static readonly string FilePath = "tickets.json";

        public static List<Ticket> LoadTickets()
        {
            if (!File.Exists(FilePath))
                return new List<Ticket>();

            string json = File.ReadAllText(FilePath);
            return JsonConvert.DeserializeObject<List<Ticket>>(json) ?? new List<Ticket>();
        }

        public static void SaveTickets(List<Ticket> tickets)
        {
            string json = JsonConvert.SerializeObject(tickets, Formatting.Indented);
            File.WriteAllText(FilePath, json);
        }
    }
}
