﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Input;

namespace TrainTicketBooking.MVVM
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private string _passengerName;
        private string _source;
        private string _destination;
        private DateTime _journeyDate = DateTime.Now.Date;
        private string _classType;
        private int _noOfTickets = 1;
        private Ticket _selectedTicket;

        public string PassengerName { get => _passengerName; set { _passengerName = value; OnPropertyChanged(nameof(PassengerName)); } }
        public string Source { get => _source; set { _source = value; OnPropertyChanged(nameof(Source)); } }
        public string Destination { get => _destination; set { _destination = value; OnPropertyChanged(nameof(Destination)); } }
        public DateTime JourneyDate { get => _journeyDate; set { _journeyDate = value; OnPropertyChanged(nameof(JourneyDate)); } }
        public string ClassType { get => _classType; set { _classType = value; OnPropertyChanged(nameof(ClassType)); } }
        public int NumberOfTickets { get => _noOfTickets; set { _noOfTickets = value; OnPropertyChanged(nameof(NumberOfTickets)); } }

        public ObservableCollection<Ticket> Bookings { get; } = new ObservableCollection<Ticket>();

        public Ticket SelectedTicket
        {
            get => _selectedTicket;
            set { _selectedTicket = value; OnPropertyChanged(nameof(SelectedTicket)); }
        }

        public ICommand BookCommand { get; }
        public ICommand ClearCommand { get; }
        public ICommand RemoveCommand { get; }
        public ICommand ShowConfirmationCommand { get; }

        public MainViewModel()
        {
            BookCommand = new RelayCommand(_ => BookTicket());
            ClearCommand = new RelayCommand(_ => ClearForm());
            RemoveCommand = new RelayCommand(_ => RemoveSelected(), _ => SelectedTicket != null);
            ShowConfirmationCommand = new RelayCommand(_ => ShowConfirmation(), _ => SelectedTicket != null);
        }

        private void BookTicket()
        {
            if (string.IsNullOrWhiteSpace(PassengerName) ||
                string.IsNullOrWhiteSpace(Source) ||
                string.IsNullOrWhiteSpace(Destination))
            {
                
                return;
            }

            var t = new Ticket
            {
                PassengerName = PassengerName,
                Source = Source,
                Destination = Destination,
                Date = JourneyDate,
                ClassType = ClassType,
                NoOfTickets = NumberOfTickets
            };

            Bookings.Add(t);
            ClearForm();
        }

        private void ClearForm()
        {
            PassengerName = string.Empty;
            Source = string.Empty;
            Destination = string.Empty;
            ClassType = string.Empty;
            NumberOfTickets = 1;
            JourneyDate = DateTime.Now.Date;
        }

        private void RemoveSelected()
        {
            if (SelectedTicket != null)
            {
                Bookings.Remove(SelectedTicket);
                SelectedTicket = null;
            }
        }

        private void ShowConfirmation()
        {
           
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
