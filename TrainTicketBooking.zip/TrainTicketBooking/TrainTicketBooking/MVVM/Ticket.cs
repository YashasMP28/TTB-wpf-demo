﻿using System;

namespace TrainTicketBooking
{
    public class Ticket
    {
        public string PassengerName { get; set; }
        public string Source { get; set; }
        public string Destination { get; set; }
        public DateTime Date { get; set; }
        public string ClassType { get; set; }
        public int NoOfTickets { get; set; }

        public override string ToString()
        {
            return $"{PassengerName} | {Source} → {Destination} | {Date:dd-MMM-yyyy} | {ClassType} x{NoOfTickets}";
        }
    }
}
