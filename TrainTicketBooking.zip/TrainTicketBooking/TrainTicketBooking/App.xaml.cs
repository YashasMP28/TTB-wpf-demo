using System.Windows;

namespace TrainTicketBooking.MVVM
{
    public partial class App : Application
    {
    }
}
